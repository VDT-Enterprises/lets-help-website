const firebaseConfig = {
  apiKey: "AIzaSyB1yGfsolTKdJdr1boBG6uMThp71T3qUqI",
  authDomain: "togetherwewin-ca1d2.firebaseapp.com",
  databaseURL: "https://togetherwewin-ca1d2.firebaseio.com",
  projectId: "togetherwewin-ca1d2",
  storageBucket: "togetherwewin-ca1d2.appspot.com",
  messagingSenderId: "635943787695",
  appId: "1:635943787695:web:66b839ea9649d854bc885a",
  measurementId: "G-4M18GG1NTV"
};