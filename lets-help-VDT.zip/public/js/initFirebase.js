const firebaseConfig = {
  apiKey: "AIzaSyAhUPdv0Jdyw2sUEzVvuA8d8Jwbaw_s_zM",
  authDomain: "lets-help-vdt.firebaseapp.com",
  databaseURL: "https://lets-help-vdt.firebaseio.com",
  projectId: "lets-help-vdt",
  storageBucket: "lets-help-vdt.appspot.com",
  messagingSenderId: "280574942584",
  appId: "1:280574942584:web:f443e5c493274fda1efc8d",
  measurementId: "G-60MVWNLSEP"
};
//firebase initalization


firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();






